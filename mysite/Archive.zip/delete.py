from models import *
import os
from timest import timeTaken

data= certificateInfo.query.all()
for i in data:
  if i.special==True:
    pass
  elif timeTaken(i) > 1800:
    os.system("rm static/"+str(i.certificte_code)+".png")
  else:
    pass
