from form import *

@app.route("/",methods=['GET', 'POST'])
@app.route("/home",methods=['GET', 'POST'])
def home():
    form = takeCode()
    if form.validate_on_submit():
        currentHolder=certificateInfo.query.filter_by(certificte_code=form.takeCertificateCode.data.upper()).first()
        if currentHolder:
            import delete
            if currentHolder.special==True:
                return render_template('certificate.html',currentHolder=currentHolder,special=True,descrpt=desp(currentHolder.certificate_design_id))
            else:
                make_certificate(str(currentHolder.certificte_code))
            return render_template('certificate.html',currentHolder=currentHolder,descrpt=desp(currentHolder.certificate_design_id))

    return render_template('home.html',takeCodeForm=form)




